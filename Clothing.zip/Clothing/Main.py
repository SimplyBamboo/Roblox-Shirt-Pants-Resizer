import os
import ttkbootstrap as ttk
from tkinter import filedialog, messagebox
from PIL import Image

def overlay_images(input_folder, overlay_path, output_folder):
    try:
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        overlay = Image.open(overlay_path).convert("RGBA")
        overlay = overlay.resize((512, 512), Image.Resampling.LANCZOS) 

        for filename in os.listdir(input_folder):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                base_image_path = os.path.join(input_folder, filename)
                base_image = Image.open(base_image_path).convert("RGBA")
                base_image = base_image.resize((512, 512), Image.Resampling.LANCZOS)  
                overlay_resized = overlay.resize(base_image.size, Image.Resampling.LANCZOS)
                combined = Image.alpha_composite(base_image, overlay_resized)
                output_path = os.path.join(output_folder, filename)
                combined.save(output_path)
        messagebox.showinfo("Success", "Images processed and saved successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def select_input_folder():
    folder = filedialog.askdirectory()
    input_folder.set(folder)

def select_overlay_file():
    file = filedialog.askopenfilename(filetypes=[("PNG files", "*.png")])
    overlay_path.set(file)

def select_output_folder():
    folder = filedialog.askdirectory()
    output_folder.set(folder)

def run_app():
    overlay_images(input_folder.get(), overlay_path.get(), output_folder.get())

root = ttk.Window(themename="darkly")
root.title("Image Overlay App")
root.geometry("500x350")  

input_folder = ttk.StringVar()
overlay_path = ttk.StringVar()
output_folder = ttk.StringVar()

main_frame = ttk.Frame(root)
main_frame.pack(pady=20, padx=20, fill="both", expand=True)

ttk.Label(main_frame, text="Input Folder:").grid(row=0, column=0, padx=10, pady=10, sticky="w")
ttk.Entry(main_frame, textvariable=input_folder, width=40).grid(row=0, column=1, padx=10, pady=10)
ttk.Button(main_frame, text="Browse", command=select_input_folder, bootstyle="primary-outline").grid(row=0, column=2, padx=10, pady=10)

ttk.Label(main_frame, text="Overlay Image:").grid(row=1, column=0, padx=10, pady=10, sticky="w")
ttk.Entry(main_frame, textvariable=overlay_path, width=40).grid(row=1, column=1, padx=10, pady=10)
ttk.Button(main_frame, text="Browse", command=select_overlay_file, bootstyle="primary-outline").grid(row=1, column=2, padx=10, pady=10)

ttk.Label(main_frame, text="Output Folder:").grid(row=2, column=0, padx=10, pady=10, sticky="w")
ttk.Entry(main_frame, textvariable=output_folder, width=40).grid(row=2, column=1, padx=10, pady=10)
ttk.Button(main_frame, text="Browse", command=select_output_folder, bootstyle="primary-outline").grid(row=2, column=2, padx=10, pady=10)

ttk.Button(main_frame, text="Run", command=run_app, bootstyle="success").grid(row=3, column=1, pady=20)

root.mainloop()